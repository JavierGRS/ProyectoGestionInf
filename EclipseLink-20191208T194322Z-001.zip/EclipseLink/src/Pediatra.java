import javax.persistence.*;

@Entity
public class Pediatra {
	@Id
	@GeneratedValue
	private int id;
	private String nombre;
	
	
	public Pediatra() {}
	
	public Pediatra(String x){
		nombre = x;
		
	}
}	


