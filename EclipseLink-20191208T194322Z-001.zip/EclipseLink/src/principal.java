import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class principal {

	private static EntityManagerFactory factory = Persistence.createEntityManagerFactory("eclipseLinkPersistenceUnit");
	private static EntityManager manager = factory.createEntityManager();
		
	public static void main(String[] args) {
		Pediatra p = new Pediatra("Pepo");
		EntityTransaction tx = manager.getTransaction();
		tx.begin();
		try {
			manager.persist(p);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		manager.close();
		factory.close();
	}
}
